import json, base64, gzip, logging, os, sys
import requests

log_level = os.getenv('LOG_LEVEL',20)
logger = logging.getLogger()
logger.setLevel(int(log_level))
gameday_properties = os.getenv('gameday_properties')

def lambda_handler(event, context):
  print(f'Event: {event}')
  compressed_payload = base64.b64decode(event['awslogs']['data'])
  json_payload = gzip.decompress(compressed_payload)
  payload = json.loads(json_payload)

  gd_payload = json.loads(gameday_properties)
  team = gd_payload['team']
  url = gd_payload['gamedayUrl']

  logging.debug(f'JSON Event: {json_payload}')

  for events in payload['logEvents']:
      refundd = events['message'].split(" ")[6]
      name = events['message'].split(" ")[4]
      logging.info(f'Refund code: {refundd}')
      parameter = {'team': f'{team}', 'refund': f'{refundd}', 'name': f'{name}'}
      response = requests.get(f'{url}',params=parameter)
      print(response.json())
  return {
      'statusCode': response.status_code,
      'body': response.json()
  }